# NetZone Booking Starter

A starter Next.js + Supabase project for NetZone. Includes a customer booking UI, estimated price calculation, Supabase insert/upload flow, and a basic authenticated admin view.

## Important: not production-ready yet
Before accepting real bookings, finish the security and availability items below. The starter deliberately does not claim that a time slot is reserved until you add server-side overlap prevention. The public form requires a payment screenshot, but the payment QR image is not yet wired into the UI.

## 1. Create Supabase
1. Create a project at https://supabase.com.
2. Open SQL Editor and run `supabase/schema.sql`.
3. In Storage, keep `payment-proofs` private.
4. Configure secure Storage policies and admin-only read/update policies before launch.

## 2. Run locally
1. Install Node.js (LTS) from https://nodejs.org.
2. Copy `.env.example` to `.env.local`.
3. Fill `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY` from Supabase project settings.
4. Run:
   ```bash
   npm install
   npm run dev
   ```
5. Open http://localhost:3000.

## 3. Admin login
Create an admin user in Supabase Authentication. Before production, add an explicit admin allowlist/role and matching RLS policies. Do not leave admin tables accessible to all authenticated users.

## 4. Before publishing
- Add server-side price validation.
- Add atomic overlap prevention for same court/date/time.
- Add private payment screenshot access for admins only.
- Wire the official QR code into the customer page.
- Add server-side email notifications to `hassanlaisa@gmail.com` (e.g. Resend) after successful database writes.
- Test on mobile and test failed uploads, double booking, invalid prices, unauthorized admin access, and email delivery.
- Deploy on Vercel and set environment variables there.

Never expose a Supabase service-role key in browser code or commit `.env.local`.
